#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar 20 05:25:27 2023
Finally clean correct RNN code 
@author: sarveshbabu
"""

"""
First let's construct the emebdding sequences
"""
import torch
import pandas as pd
import torch.nn as nn
from transformers import BertTokenizerFast, BertModel
import RNN_config
from torch.nn.utils.rnn import pack_padded_sequence
from torch.nn.utils.rnn import pad_packed_sequence
from sklearn.model_selection import train_test_split
import torch.utils.data as data
from tqdm import tqdm

device = RNN_config.device
torch.backends.cuda.max_split_size_mb = 1

# Load the tokenizer and model
model1 = BertModel.from_pretrained('bert-base-uncased')
tokenizer = BertTokenizerFast.from_pretrained('bert-base-uncased')

learning_rate = RNN_config.learning_rate

model1.to(device)
sequences = []
sequenceLabels = []

#import df as df 
df = pd.read_csv(RNN_config.data_url, dtype=str)
df = df.dropna()

#selects all the patient_ids
patient_ids_df = df.loc[:, ['case_id']].drop_duplicates()
case_id_list = patient_ids_df['case_id'].tolist()

case_id_list = patient_ids_df['case_id'].values

for patient in tqdm(patient_ids_df['case_id'].values):
    label = df.loc[df['case_id'] == patient, 'surgery_failed'].iloc[0]
    filtered_df = df.loc[df['case_id'] == patient]
    if not filtered_df.empty:
        label = filtered_df['surgery_failed'].iloc[0]
    else:
        print('this patient labels not there')
    sequenceLabels.append(label)
    notes = df.loc[df['case_id'] == patient]
    notes = notes["notes"].astype(str).values.tolist()
    #print(notes)
    input_id_dic = tokenizer(notes, add_special_tokens=True, truncation = True, max_length = 512, padding = 'max_length')
    input_ids = torch.tensor(input_id_dic['input_ids']).to(device)
    input_tensor = torch.utils.data.DataLoader(input_ids, batch_size=32)
    cls_tokens = []
    for batch in input_tensor:
        with torch.no_grad():
            outputs = model1(batch)
        hidden_states = outputs[0]
        cls_token = hidden_states[:, 0, :]
        cls_tokens.append(cls_token)
    cls_tokens = torch.cat(cls_tokens)
    sequences.append(cls_tokens)


import pickle 
with open('sequences.pickle', 'wb') as handle:
    pickle.dump(sequences, handle, protocol=pickle.HIGHEST_PROTOCOL)

"""
import pickle
with open('sequences.pickle', 'rb') as handle:
    sequences_saved = pickle.load(handle)
"""

"""
define the different models 
We need to be able to handle variable length inputs which is a tad bit tricky. 
Let's first try it in Keras. Then in pyTorch where we can then do the time embeddings. 
"""
num_classes = 2
input_dim = len(sequences[0][0])
seq_len = len(max(sequences, key=len))

from keras.models import Sequential
from keras.layers import Dense, LSTM, Bidirectional, Embedding

model_keras = Sequential()
model_keras.add(Embedding(input_dim=input_dim, output_dim=128, input_length=seq_len))
model_keras.add(Bidirectional(LSTM(units=64, return_sequences=True)))
model_keras.add(Bidirectional(LSTM(units=32)))
model_keras.add(Dense(units=1, activation='sigmoid'))

# Compile the model
model_keras.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

class BiLSTM(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, num_classes):
        super(BiLSTM, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True, bidirectional=True)
        self.fc = nn.Linear(hidden_size * 2, num_classes)

    def forward(self, x):
        # Calculate the lengths of the sequences
        lengths = [len(seq) for seq in x]
        lengths_tensor = torch.LongTensor(lengths)
        # Sort input sequences by length in descending order
        sorted_lengths, sorted_idx = lengths_tensor.sort(descending=True)
        sorted_x = x[sorted_idx]
        # Pack padded sequences
        packed_x = pack_padded_sequence(sorted_x, sorted_lengths, batch_first=True)
        # Initialize hidden and cell states
        h0 = torch.zeros(self.num_layers * 2, sorted_x.size(0), self.hidden_size).to(x.device)
        c0 = torch.zeros(self.num_layers * 2, sorted_x.size(0), self.hidden_size).to(x.device)
        # Forward propagate LSTM
        packed_out, _ = self.lstm(packed_x, (h0, c0))
        # Unpack packed sequences
        out, _ = pad_packed_sequence(packed_out, batch_first=True)
        # Unsort output sequences to restore the original order
        _, unsorted_idx = sorted_idx.sort()
        out = out[unsorted_idx]
        # Pass output through fully-connected layer
        out = self.fc(out[:, -1, :])  # Use the last output of each sequence
        return out

"""
Get the data ready for Keras' model 
"""
# Split the data into training, validation, and test sets
X_train_val, X_test, y_train_val, y_test = train_test_split(sequences, sequenceLabels, test_size=0.2, random_state=42, stratify=sequenceLabels)
X_train, X_val, y_train, y_val = train_test_split(X_train_val, y_train_val, test_size=0.25, random_state=42, stratify=y_train_val)

from torch.utils.data import Dataset, DataLoader
#The Tensor_Dataset class is not sufficient for this task, thus we have to create a custom dataset class for the embedding sequences 
class EmbeddingDataset(Dataset):
    def __init__(self, data1, labels):
        self.data1 = data1
        self.labels = labels
    def __len__(self):
        return len(self.data1)

    def __getitem__(self, index):
        return self.data1[index], self.labels[index]

def collate_fn(batch):
    inputs = [item[0] for item in batch]
    labels = [item[1] for item in batch]
    my_tensor = torch.stack(labels).to(device)
    padded_inputs = torch.nn.utils.rnn.pad_sequence(inputs, batch_first=True, padding_value=0)
    return padded_inputs, my_tensor

batch_size = 32 
train_dataset = EmbeddingDataset(X_train, torch.tensor(y_train))
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, collate_fn = collate_fn)

val_dataset = EmbeddingDataset(X_val,torch.tensor(y_val))
val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, collate_fn = collate_fn)

test_dataset = EmbeddingDataset(X_test,torch.tensor(y_test))
test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, collate_fn = collate_fn)






"""
Train the different models
"""

#train model 1 
def train_model_1(): 
    model_keras.fit(X_train, y_train, epochs=10, batch_size=32, validation_data=(X_val, y_val))
#train model 2 
def train_model_2():
    model = BiLSTM(input_dim, hidden_size = 100, num_layers=10, num_classes=num_classes).to(device)

    # Define the loss function and optimizer
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

    best_val_loss = float('inf')

    for epoch in range(RNN_config.num_train_epochs):
        model.train()
        total_loss = 0
        total_correct = 0
        total_processed = 0

        for i, (inputs, labels) in enumerate(train_loader):
            optimizer.zero_grad()
            # forward pass
            outputs = model(inputs)

            # compute loss and gradients
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            # keep track of total loss and accuracy
            total_loss += loss.item() * inputs.size(0)
            total_correct += torch.sum(torch.argmax(outputs, dim=1) == labels).item()
            total_processed += inputs.size(0)

        train_loss = total_loss / total_processed
        train_acc = total_correct / total_processed

        # evaluate on validation set
        model.eval()
        total_loss = 0
        total_correct = 0
        total_processed = 0

        with torch.no_grad():
            for inputs, labels in val_loader:
                # forward pass
                outputs = model(inputs)

                # compute loss and accuracy
                loss = criterion(outputs, labels)
                total_loss += loss.item() * inputs.size(0)
                total_correct += torch.sum(torch.argmax(outputs, dim=1) == labels).item()
                total_processed += inputs.size(0)

        val_loss = total_loss / total_processed
        val_acc = total_correct / total_processed

        # print training and validation metrics for each epoch
        print('Epoch [{}/{}], Train Loss: {:.4f}, Train Acc: {:.4f}, Val Loss: {:.4f}, Val Acc: {:.4f}'
              .format(epoch+1, RNN_config.num_train_epochs, train_loss, train_acc, val_loss, val_acc))

        # save the model if the validation loss is the best seen so far
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            torch.save(model.state_dict(), 'best_model.pth')

"""
Run models 
"""
train_model_1()
train_model_2()

