"""
import nemo
# import nemo_asr

from nlpreprcessing.annotation2BIO import pre_processing, generate_BIO
txt, sents = pre_processing("./test.txt")
generate_BIO(sents, [])


from nlpreprcessing.text_process.sentence_tokenization import SentenceBoundaryDetection
processor = SentenceBoundaryDetection()
processor.sent_tokenizer("this is a test!")
"""

import numpy as np
from matplotlib import pyplot as plt
import torch
from transformers import AutoTokenizer, AutoModel

PATH_GATORTRON = "./gatortron/MegatronBERT.nemo"

if __name__ == "__main__":

    tokenizer = AutoTokenizer.from_pretrained("emilyalsentzer/Bio_ClinicalBERT")
    bio_bert = AutoModel.from_pretrained("emilyalsentzer/Bio_ClinicalBERT")
    
    input = tokenizer("The surgery is most likely going to fail for the patient", return_tensors="pt")
    output = bio_bert(**input)
    
    print(output)

    """
    Input (after tokenizer): input_ids, token type ids (0 or 1 for question or context), attention mask
    Model returns pooler output and last_hidden state -> perfect
    
     """



    # output = megatron(input)
    # print(output)

    # neural_factory = nemo.core.NeuralModuleFactory(backend='pytorch', local_rank=None)
    # megatron = neural_factory.restore_from(PATH_GATORTRON, restore_map=None)

    # input = "The surgery is most likely going to fail for the patient"

    # output = megatron(input)
    # print(output)