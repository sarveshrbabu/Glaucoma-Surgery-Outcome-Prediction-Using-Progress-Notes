import numpy as np
import json
import os
from matplotlib import pyplot as plt


def sort_according_to_first_list(*args):
    """
    Sort the input list according to the ordering of the first one
    """
    assert len(args) > 0

    output = []
    for i, arg in enumerate(args):
        if i == 0:
            idx_order = np.argsort(arg)
        print(arg)
        output.append([arg[j] for j in idx_order])
        
    return output


def plot_model_outputkey_comparison(folder_name = "./models/results", metric = "accuracy"):
    
    model_name_shortened = {
        'LinearDiscriminantAnalysis': 'LDA',
        'GaussianNB': 'NB',
        'MLPClassifier': 'MLP',
        'LogisticRegression': 'Log. Reg.',
        'KNeighborsClassifier': 'KNN',
        'DecisionTreeClassifier': 'Dec. Tree',
        'SVC': 'SVM',
        'RandomForestClassifier': 'RF',
        'GradientBoostingClassifier': 'XGBoost'
        }
    
    Y_list = []
    X = []
    output_keys = ["surgery_failed", "iop_failure", "med_failure", "surg_failure"]
    for output_key in output_keys :
        file_name = folder_name + "/" + output_key + "_eval.json"
        with open(file_name, "r") as f:
            Y = []
            x = f.read()
            eval_dic = json.loads(x)

            for model_name in eval_dic.keys():
                Y.append(eval_dic[model_name][metric])
                if output_key == output_keys[0]: X.append(model_name_shortened[model_name])

            Y_list.append(Y)

    
    
    Y1, Y2, Y3, Y4, X = sort_according_to_first_list(Y_list[0], Y_list[1], Y_list[2], Y_list[3], X)

    Y1, Y2, Y3, Y4, X = sort_according_to_first_list(Y_list[3], Y_list[2], Y_list[1], Y_list[0], X)
    Y4 = Y1
    
    X_axis = np.arange(len(X))
    _, ax = plt.subplots(figsize=(12, 8))
    print(Y_list, X)
    ax.bar(X_axis, Y4, 0.2, edgecolor="black", label=output_keys[3])
    # ax.bar(X_axis - 0.3, Y4, 0.2, edgecolor="black", label=output_keys[3])
    # ax.bar(X_axis - 0.1, Y3, 0.2, edgecolor="black", label=output_keys[2])
    # ax.bar(X_axis + 0.1, Y2, 0.2, edgecolor="black", label=output_keys[1])
    # ax.bar(X_axis + 0.3, Y1, 0.2, edgecolor="black", label=output_keys[0])

    # for i, v in enumerate(Y1):
    #     ax.annotate(str(round(100*v)) + "%", xy=(X_axis[i] + 0.3, v), xytext=(0, 5),
    #             textcoords="offset points", ha='center', va='bottom')
    
    for i, v in enumerate(Y4):
        ax.annotate(str(round(100*v)) + "%", xy=(X_axis[i], v), xytext=(0, 5),
                textcoords="offset points", ha='center', va='bottom')

    plt.xticks(X_axis, X)
    plt.xticks(rotation = 45)
    # ax.tick_params(axis='x', which='minor', labelsize=8)
    plt.xlabel("Model/ Output key")
    plt.ylabel("Model accuracy")
    plt.title("Performance of the best performing model for each model/ output key")
    plt.legend(loc="lower right")
    os.chdir("./models")
    plt.savefig("Model & outputkey performance benchmark - Surg failed.png")
    os.chdir("..")
    plt.close()

if __name__ == "__main__":
    plot_model_outputkey_comparison(metric="accuracy")
