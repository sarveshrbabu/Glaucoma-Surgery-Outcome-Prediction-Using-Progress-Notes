import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.metrics import accuracy_score
import sys

sys.path.insert(0, '/home/sambarry_stanford_edu/glaucoma_outcome_pred')
from feature_engineering.feature_engineering import *
from utils import *


class ANN(nn.Module):
    def __init__(self, input_size, layer_sizes, activations):
        super(ANN, self).__init__()
        self.layers = nn.ModuleList()
        
        # Input
        self.layers.append(nn.Linear(input_size, layer_sizes[0]))
        self.layers.append(activations[0]())
        
        # Hidden
        for i in range(1, len(layer_sizes)):
            self.layers.append(nn.Linear(layer_sizes[i-1], layer_sizes[i]))
            self.layers.append(activations[i]())
        
        # Output
        self.layers.append(nn.Linear(layer_sizes[-1], 1))
        self.layers.append(nn.Sigmoid())

    def forward(self, x):
        for layer in self.layers:
            x = layer(x)
        return x

class Trainer:
    def __init__(self, model, criterion=nn.BCELoss(), optimizer=optim.Adam, device=torch.device("cpu")):
        self.model = model
        self.criterion = criterion
        self.optimizer = optimizer(model.parameters())
        self.device = device

    def train(self, X_train, Y_train, X_val, Y_val, num_epochs=10):
        self.model.to(self.device)
        X_train_tensor = torch.Tensor(X_train).to(self.device)
        Y_train_tensor = torch.Tensor(Y_train).view(-1, 1).to(self.device)
        X_val_tensor = torch.Tensor(X_val).to(self.device)
        Y_val_tensor = torch.Tensor(Y_val).view(-1, 1).to(self.device)

        for epoch in range(num_epochs):
            # Train the model
            self.model.train()
            self.optimizer.zero_grad()
            outputs = self.model(X_train_tensor)
            loss = self.criterion(outputs, Y_train_tensor)
            loss.backward()
            self.optimizer.step()

            # Evaluate the model on the validation set
            self.model.eval()
            with torch.no_grad():
                val_outputs = self.model(X_val_tensor)
                val_loss = self.criterion(val_outputs, Y_val_tensor)
                val_preds = (val_outputs > 0.5).float()
                val_accuracy = accuracy_score(Y_val_tensor.cpu(), val_preds.cpu())

            print(f"Epoch [{epoch+1}/{num_epochs}], Train Loss: {loss.item():.4f}, Val Loss: {val_loss.item():.4f}, Val Accuracy: {val_accuracy:.4f}")

    def test(self, X_test, Y_test):
        self.model.to(self.device)
        X_test_tensor = torch.Tensor(X_test).to(self.device)
        Y_test_tensor = torch.Tensor(Y_test).view(-1, 1).to(self.device)
        test_outputs = self.model(X_test_tensor)
        test_preds = (test_outputs > 0.5).float()
        test_accuracy = accuracy_score(Y_test_tensor.cpu(), test_preds.cpu())
        print(f"Test Accuracy: {test_accuracy:.4f}")

def run(
    csv_path = "/home/sambarry_stanford_edu/glaucoma_outcome_pred/data/data_glaucoma_surg.csv",
    output_key="surgery_failed",
    test_size=TEST_SIZE,
    eval_size=EVAL_SIZE,
    seed=SEED_DATASET_SPLIT):

    # Keeping mrn for train to enable the next split
    X_train, X_test, Y_train, Y_test = get_datasets(
            csv_path, output_key, test_size=test_size, seed=seed, keep_mrn=True
        )
    X_test.drop(["mrn"], axis=1, inplace=True)

    X_train, X_val, Y_train, Y_val = custom_train_test_split(
        X_train, Y_train, alpha = 1-eval_size, seed=seed, keep_mrn=False
        )

    activations = [nn.ReLU, nn.Tanh]
    model = ANN(input_size=10, layer_sizes=[64, 32, 16], activations=activations)

    trainer = Trainer(model)
    
    trainer.train(X_train, Y_train, X_val, Y_val)
    trainer.test(X_test, Y_test)

if __name__ == "__main__":
    run()
    


