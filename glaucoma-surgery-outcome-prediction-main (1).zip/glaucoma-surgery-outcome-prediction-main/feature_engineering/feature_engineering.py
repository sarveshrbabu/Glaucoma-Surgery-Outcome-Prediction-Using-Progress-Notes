import pandas as pd
import os
import numpy as np
import sys
import json
from collections import defaultdict
import seaborn as sns
import lime
import lime.lime_tabular
import shap
from textwrap import wrap
from matplotlib import pyplot as plt
import lazypredict
from lazypredict.Supervised import LazyClassifier
from sklearn.decomposition import PCA
from sklearn.model_selection import train_test_split
from sklearn.utils import all_estimators
from sklearn.base import ClassifierMixin


removed_classifiers = [
    # Orignal list of classifier removed from the lazy classifier module
    "ClassifierChain",
    "ComplementNB",
    "GradientBoostingClassifier",
    "GaussianProcessClassifier",
    "HistGradientBoostingClassifier",
    "MLPClassifier",
    "LogisticRegressionCV",
    "MultiOutputClassifier",
    "MultinomialNB",
    "OneVsOneClassifier",
    "OneVsRestClassifier",
    "OutputCodeClassifier",
    "RadiusNeighborsClassifier",
    "VotingClassifier",
    # Additional  list of classifier removed (take  ages)
    "XGBRegressor",
    "LGBMRegressor",
]

CLASSIFIERS = [
    est
    for est in all_estimators()
    if (issubclass(est[1], ClassifierMixin) and (est[0] not in removed_classifiers))
]


def return_datasets(
    csv_path="/home/sambarry_stanford_edu/glaucoma_outcome_pred/data/data_glaucoma_surg.csv",
    adjust_laterality_features=True,
    remove_correlated_encoding=True,
    split_per_surg=False,
    approachs={
        "glaucoma_meds": 2,
        "general_meds": 2,
        "diagnoses": 1,
        "diagnoses_1_nbr_char": 2,
    },
    pca_dic={
        "glaucoma_meds": False,
        "general_meds": False,
        "diagnoses": False,
        "nbr_features": 100,
    },
    var_elim_dict={
        "glaucoma_meds": False,
        "general_meds": False,
        "diagnoses": False,
        "nbr_features": 100,
    },
):
    """
    Takes the path to the preprocessed CSV and options as input and output a proper X/Y dataset ready for modeling
    Input:
        csv_path
    Output:
        X
        Y
    """
    assert (
        approachs["glaucoma_meds"] in [1, 2]
        and approachs["general_meds"] in [1, 2]
        and approachs["diagnoses"] in [1, 2]
        and approachs["diagnoses_1_nbr_char"] in [-1, 1, 2]
    )

    # Fetching the dataframe and sorting it
    try:
        df = pd.read_csv(csv_path)
    except FileNotFoundError:
        df = pd.read_csv(os.getcwd()[:-7] + "/data/data_glaucoma_surg.csv")

    df.sort_values(by=["proc_date", "mrn"], ascending=True, inplace=True)

    # Selecting the med/diagnose approach
    two_to_one = lambda x: str(2 * (x == 1) + 1 * (x == 2))

    glaucoma_meds_to_drop = [
        col
        for col in df.columns
        if "glm" + two_to_one(approachs["glaucoma_meds"]) in col
    ]
    general_meds_to_drop = [
        col
        for col in df.columns
        if "gem" + two_to_one(approachs["glaucoma_meds"]) in col
    ]

    if approachs["diagnoses"] == 2:
        diagnoses_to_drop = [col for col in df.columns if "icd1" in col]
    elif approachs["diagnoses"] == 1:
        col_to_keep = "icd1_" + str(approachs["diagnoses_1_nbr_char"])
        diagnoses_2_to_drop = [col for col in df.columns if "icd2" in col]
        diagnoses_1_to_drop = [
            col for col in df.columns if ("icd1" in col and col_to_keep not in col)
        ]
        diagnoses_to_drop = diagnoses_1_to_drop + diagnoses_2_to_drop
    else:
        raise NotImplementedError()

    id_to_drop = ["case_id", "pat_enc_csn_id", "proc_date"]
    df = df.drop(
        id_to_drop + glaucoma_meds_to_drop + general_meds_to_drop + diagnoses_to_drop,
        axis=1,
    )

    # Adjusting the laterality if needed
    if adjust_laterality_features:
        df["to"] = df["tod_before_surg"].where(
            df["or_laterality_right"] == 1, df["tos_before_surg"]
        )
        df["bcvalogmaro"] = df["bcvalogmarod_before_surg"].where(
            df["or_laterality_right"] == 1, df["bcvalogmaros_before_surg"]
        )
        df["ccto"] = df["cctod_before_surg"].where(
            df["or_laterality_right"] == 1, df["cctos_before_surg"]
        )
        df["mrxospheqv"] = df["mrxodspheqv_before_surg"].where(
            df["or_laterality_right"] == 1, df["mrxosspheqv_before_surg"]
        )

        old_unilateral_col = [
            "tod_before_surg",
            "tos_before_surg",
            "bcvalogmarod_before_surg",
            "bcvalogmaros_before_surg",
            "cctod_before_surg",
            "cctos_before_surg",
            "mrxodspheqv_before_surg",
            "mrxosspheqv_before_surg",
        ]
        df = df.drop(old_unilateral_col, axis=1)

    # Removing the default feature of each one-hot-encoded field to reduce multicolinearity
    if remove_correlated_encoding:
        default_features = [
            "or_laterality_right",
            "white",
            "m",
            "alcohol_use_yes",
            "ill_drug_use_yes",
            "tobacco_use_yes",
            "vacorr_before_surg_no_correction",
        ]

        df = df.drop(default_features, axis=1)

    # Performing PCA/ Variance Elimination
    for key in ["glaucoma_meds", "general_meds", "diagnoses"]:
        if pca_dic[key] and var_elim_dict[key]:
            raise NotImplementedError()  # We shouldn't have both PCA and Variance Elimination!
        if pca_dic[key]:
            if key == "glaucoma_meds":
                cols_input = [col for col in df.columns if "glm" in col]
                cols_output = [
                    "glm_pca_" + str(i) for i in range(1, pca_dic["nbr_features"] + 1)
                ]
            elif key == "general_meds":
                cols_input = [col for col in df.columns if "gem" in col]
                cols_output = [
                    "gem_pca_" + str(i) for i in range(1, pca_dic["nbr_features"] + 1)
                ]
            else:
                cols_input = [col for col in df.columns if "icd" in col]
                cols_output = [
                    "icd_pca_" + str(i) for i in range(1, pca_dic["nbr_features"] + 1)
                ]

            df_pca = (df[cols_input] - df[cols_input].mean()) / df[cols_input].std()
            df_pca = df_pca.fillna(0)

            pca = PCA(n_components=pca_dic["nbr_features"])
            pca_df = pd.DataFrame(data=pca.fit_transform(df_pca), columns=cols_output)

            df = pd.concat([df, pca_df], axis=1)
            df = df.drop(cols_input, axis=1)

        elif var_elim_dict[key]:
            if key == "glaucoma_meds":
                cols_input = [col for col in df.columns if "glm" in col]
            elif key == "general_meds":
                cols_input = [col for col in df.columns if "gem" in col]
            else:
                cols_input = [col for col in df.columns if "icd" in col]

            variance = df[cols_input].var()
            variance_sorted = variance.sort_values(ascending=False)
            top_cols = list(variance_sorted[: var_elim_dict["nbr_features"]].index)
            cols_to_drop = [col for col in cols_input if col not in top_cols]

            df = df.drop(cols_to_drop, axis=1)

    target_col = [
        "iop_below_5",
        "iop_above_17",
        "iop_above_19",
        "iop_above_21",
        "iop_failure",
        "med_failure",
        "revision_after_surg",
        "other_surg_after_surg",
        "surg_failure",
        "surgery_failed",
    ]

    # Returning the dataframe, splitting per surgery type if needed
    if split_per_surg:
        result_dic = {}

        # surg_types = ["Tube Shunt", "Trabeculectomy", "MIGS"]
        surg_types = ["tube_shunt", "trabeculectomy", "migs"]
        for surg_type in surg_types:
            # df_filtered = df[df["surg_type"] == surg_type]
            df_filtered = df[df["surg_type" + surg_type] == 1]
            result_dic[surg_type] = {}
            result_dic[surg_type]["X"] = df_filtered.drop(target_col, axis=1)

            for col in target_col:
                result_dic[surg_type][col] = df_filtered[col]

        return result_dic

    else:
        X = df.drop(target_col, axis=1)
        result_dic = {"X": X}

        for col in target_col:
            result_dic[col] = df[col]

        return result_dic


def return_datasets_with_only_approach_features(
    approach_name,
    approach_value,
    csv_path="/home/sambarry_stanford_edu/glaucoma_outcome_pred/data/data_glaucoma_surg.csv",
):

    target_col = [
        "iop_below_5",
        "iop_above_17",
        "iop_above_19",
        "iop_above_21",
        "iop_failure",
        "med_failure",
        "revision_after_surg",
        "other_surg_after_surg",
        "surg_failure",
        "surgery_failed",
    ]

    df = pd.read_csv(csv_path)
    df.sort_values(by=["proc_date", "mrn"], ascending=True, inplace=True)
    cols = df.columns

    if approach_name == "glaucoma_meds":
        col_to_keep = [col for col in cols if "gem" + approach_value in col]
    elif approach_name == "general_meds":
        col_to_keep = [col for col in cols if "glm" + approach_value in col]
    elif approach_name == "diagnoses":
        col_to_keep = [col for col in cols if "icd" + approach_value in col]
    else:
        raise NotImplemented()

    X = df.loc[:, col_to_keep]
    result_dic = {"X": X}

    for col in target_col:
        result_dic[col] = df[col]

    return result_dic


def evaluate_approaches_all_features(
    nbr_iter=10,
    csv_path="/home/sambarry_stanford_edu/glaucoma_outcome_pred/data/data_glaucoma_surg.csv",
    write_path="/home/sambarry_stanford_edu/glaucoma_outcome_pred/feature_engineering/results/eval_all_features.txt",
):
    eval_dic = {
        "glaucoma_meds": {1: defaultdict(float), 2: defaultdict(float)},
        "general_meds": {1: defaultdict(float), 2: defaultdict(float)},
        "diagnoses": {1: defaultdict(float), 2: defaultdict(float)},
        "diagnoses_1_nbr_char": {
            -1: defaultdict(float),
            1: defaultdict(float),
            2: defaultdict(float),
        },
    }

    iteration_nbr_dic = {
        "glaucoma_meds": {1: 0, 2: 0},
        "general_meds": {1: 0, 2: 0},
        "diagnoses": {1: 0, 2: 0},
        "diagnoses_1_nbr_char": {
            -1: 0,
            1: 0,
            2: 0,
        },
    }

    i = 0
    total_nbr_loop = 2 * 2 * 2 * 3 * nbr_iter

    for glaucoma_meds_approach in [1, 2]:
        for general_meds_approach in [1, 2]:
            for diagnoses_approach in [1, 2]:
                for diagnoses_nbr_char in [-1, 1, 2]:
                    i += 1
                    sys.stdout.write("Entering loop {}/{}".format(i, total_nbr_loop))
                    approachs_input = {
                        "glaucoma_meds": glaucoma_meds_approach,
                        "general_meds": general_meds_approach,
                        "diagnoses": diagnoses_approach,
                        "diagnoses_1_nbr_char": diagnoses_nbr_char,
                    }
                    dict_data = return_datasets(csv_path, approachs=approachs_input)

                    X = dict_data["X"]
                    for output_key in [
                        "iop_failure",
                        "med_failure",
                        "surg_failure",
                        "surgery_failed",
                    ]:
                        for it in range(nbr_iter):
                            Y = dict_data[output_key]

                            X_train, X_test, y_train, y_test = train_test_split(
                                X, Y, test_size=0.2, random_state=it
                            )
                            clf = LazyClassifier(
                                verbose=0,
                                ignore_warnings=False,
                                custom_metric=None,
                                classifiers=CLASSIFIERS,
                            )
                            models, _ = clf.fit(X_train, X_test, y_train, y_test)
                            top_acc_mean = (
                                models.sort_values("Accuracy", ascending=False)
                                .head(3)["Accuracy"]
                                .mean()
                            )

                            eval_dic["glaucoma_meds"][glaucoma_meds_approach][
                                output_key
                            ] += top_acc_mean
                            eval_dic["general_meds"][general_meds_approach][
                                output_key
                            ] += top_acc_mean
                            eval_dic["diagnoses"][diagnoses_approach][
                                output_key
                            ] += top_acc_mean
                            eval_dic["diagnoses_1_nbr_char"][diagnoses_nbr_char][
                                output_key
                            ] += top_acc_mean

                            iteration_nbr_dic["glaucoma_meds"][
                                glaucoma_meds_approach
                            ] += 1
                            iteration_nbr_dic["general_meds"][
                                general_meds_approach
                            ] += 1
                            iteration_nbr_dic["diagnoses"][diagnoses_approach] += 1
                            iteration_nbr_dic["diagnoses_1_nbr_char"][
                                diagnoses_nbr_char
                            ] += 1

    for feature_type in eval_dic.keys():
        for approach in eval_dic[feature_type].keys():
            for output_key in [
                "iop_failure",
                "med_failure",
                "surg_failure",
                "surgery_failed",
            ]:

                eval_dic[feature_type][approach][output_key] /= (
                    iteration_nbr_dic[feature_type][approach] // 4
                )

    if write_path:
        with open(write_path, "w") as f:
            f.write(json.dumps(eval_dic))

    return eval_dic


def evaluate_approaches_only_one_approach_feature(
    nbr_iter=10,
    csv_path="/home/sambarry_stanford_edu/glaucoma_outcome_pred/data/data_glaucoma_surg.csv",
    write_path="/home/sambarry_stanford_edu/glaucoma_outcome_pred/feature_engineering/results/eval_only_features.txt",
):
    eval_dic = {
        "glaucoma_meds": {"1": defaultdict(float), "2": defaultdict(float)},
        "general_meds": {"1": defaultdict(float), "2": defaultdict(float)},
        "diagnoses": {"1": defaultdict(float), "2": defaultdict(float)},
        "diagnoses_1_nbr_char": {
            "-1": defaultdict(float),
            "1": defaultdict(float),
            "2": defaultdict(float),
        },
    }

    for approach in ["glaucoma_meds", "general_meds"]:
        for approach_value in ["1", "2"]:
            dict_data = return_datasets_with_only_approach_features(
                approach, approach_value, csv_path
            )
            X = dict_data["X"]
            for output_key in [
                "iop_failure",
                "med_failure",
                "surg_failure",
                "surgery_failed",
            ]:
                for it in range(nbr_iter):
                    Y = dict_data[output_key]

                    clf = LazyClassifier(
                        verbose=0, ignore_warnings=False, custom_metric=None
                    )
                    X_train, X_test, y_train, y_test = train_test_split(
                        X, Y, test_size=0.2, random_state=it
                    )
                    models, _ = clf.fit(X_train, X_test, y_train, y_test)
                    top_acc_mean = (
                        models.sort_values("Accuracy", ascending=False)
                        .head(3)["Accuracy"]
                        .mean()
                    )

                    eval_dic[approach][approach_value][output_key] += top_acc_mean
                eval_dic[approach][approach_value][output_key] /= nbr_iter

    for approach in ["diagnoses"]:
        for approach_value in ["1_-1", "1_1", "1_2", "2"]:
            dict_data = return_datasets_with_only_approach_features(
                approach, approach_value, csv_path
            )
            X = dict_data["X"]
            for output_key in [
                "iop_failure",
                "med_failure",
                "surg_failure",
                "surgery_failed",
            ]:
                for it in range(nbr_iter):
                    Y = dict_data[output_key]

                    clf = LazyClassifier(
                        verbose=0, ignore_warnings=False, custom_metric=None
                    )
                    X_train, X_test, y_train, y_test = train_test_split(
                        X, Y, test_size=0.2, random_state=it
                    )
                    models, _ = clf.fit(X_train, X_test, y_train, y_test)
                    top_acc_mean = (
                        models.sort_values("Accuracy", ascending=False)
                        .head(3)["Accuracy"]
                        .mean()
                    )

                    if approach_value == "2":
                        eval_dic["diagnoses"]["2"][output_key] += top_acc_mean
                    elif approach_value == "1_-1":
                        eval_dic["diagnoses_1_nbr_char"]["-1"][
                            output_key
                        ] += top_acc_mean
                    elif approach_value == "1_1":
                        eval_dic["diagnoses_1_nbr_char"]["1"][
                            output_key
                        ] += top_acc_mean
                    elif approach_value == "1_2":
                        eval_dic["diagnoses_1_nbr_char"]["2"][
                            output_key
                        ] += top_acc_mean
                    else:
                        raise NotImplementedError()

                if approach_value == "2":
                    eval_dic["diagnoses"]["2"][output_key] /= nbr_iter
                elif approach_value == "1_-1":
                    eval_dic["diagnoses_1_nbr_char"]["-1"][output_key] /= nbr_iter
                elif approach_value == "1_1":
                    eval_dic["diagnoses_1_nbr_char"]["1"][output_key] /= nbr_iter
                elif approach_value == "1_2":
                    eval_dic["diagnoses_1_nbr_char"]["2"][output_key] /= nbr_iter
                else:
                    raise NotImplementedError()

    if write_path:
        with open(write_path, "w") as f:
            f.write(json.dumps(eval_dic))

    return eval_dic


def plot_evaluate_approaches(
    read_path="/home/sambarry_stanford_edu/glaucoma_outcome_pred/feature_engineering/results/eval_all_features.txt",
    title_prefix="All - ",
):
    with open(read_path, "r") as f:
        eval_dic = json.loads(f.read())

    X = ["iop_failure", "med_failure", "surg_failure", "surgery_failed"]

    for key in ["glaucoma_meds", "general_meds"]:
        Y_1 = [eval_dic[key]["1"][x] for x in X]
        Y_2 = [eval_dic[key]["2"][x] for x in X]

        X_axis = np.arange(len(X))
        _, ax = plt.subplots()
        ax.bar(
            X_axis - 0.125, Y_1, 0.25, edgecolor="black", label="Approach 1 (group sum)"
        )
        ax.bar(
            X_axis + 0.125,
            Y_2,
            0.25,
            edgecolor="black",
            label="Approach 2 (add all id)",
        )
        ax.set_ylim(0.6, 0.9)

        plt.xticks(X_axis, X)
        plt.xlabel("Output signal")
        plt.ylabel("Top Model Accuracy")
        title = title_prefix + "Comparison of FE approaches for " + key
        plt.title(title)
        plt.legend(loc="lower right")
        os.chdir("./feature_engineering")
        plt.savefig(title + ".png")
        os.chdir("..")
        plt.close()

    for key in ["diagnoses"]:
        Y_1_m_1 = [eval_dic["diagnoses_1_nbr_char"]["-1"][x] for x in X]
        Y_1_p_1 = [eval_dic["diagnoses_1_nbr_char"]["1"][x] for x in X]
        Y_1_p_2 = [eval_dic["diagnoses_1_nbr_char"]["2"][x] for x in X]
        Y_2 = [eval_dic["diagnoses"]["2"][x] for x in X]

        X_axis = np.arange(len(X))
        _, ax = plt.subplots()
        ax.bar(
            X_axis - 0.3,
            Y_1_m_1,
            0.2,
            edgecolor="black",
            label="Approach 1, -1 char (aggregate by family)",
        )
        ax.bar(
            X_axis - 0.1,
            Y_1_p_1,
            0.2,
            edgecolor="black",
            label="Approach 1, 1 char (aggregate by family)",
        )
        ax.bar(
            X_axis + 0.1,
            Y_1_p_2,
            0.2,
            edgecolor="black",
            label="Approach 1, 2 char (aggregate by family)",
        )
        ax.bar(
            X_axis + 0.3, Y_2, 0.2, edgecolor="black", label="Approach 2 (add all icd)"
        )
        ax.set_ylim(0.6, 0.9)

        plt.xticks(X_axis, X)
        plt.xlabel("Output signal")
        plt.ylabel("Top Model Accuracy")
        title = title_prefix + "Comparison of FE approaches for diagnoses"
        plt.title(title)
        plt.legend(loc="lower right")
        os.chdir("./feature_engineering")
        plt.savefig(title + ".png")
        os.chdir("..")
        plt.close()


def evaluate_and_plot_laterality_approach(
    csv_path="/home/sambarry_stanford_edu/glaucoma_outcome_pred/data/data_glaucoma_surg.csv",
    nbr_iter=10,
    approachs={
        "glaucoma_meds": 2,
        "general_meds": 2,
        "diagnoses": 2,
        "diagnoses_1_nbr_char": 1,
    },
):

    eval_dic = {
        "all_features": defaultdict(float),
        "only_laterality": defaultdict(float),
    }

    return_datasets()
    # X1: All features, no matter the laterality
    dict_all_features = return_datasets(
        csv_path, adjust_laterality_features=False, approachs=approachs
    )
    X1 = dict_all_features["X"]

    # X2: For the lateral features (tod, bcva, ...) we only keep the one of the laterality
    dict_filtered_features = return_datasets(
        csv_path, adjust_laterality_features=True, approachs=approachs
    )
    X2 = dict_filtered_features["X"]

    for output_key in [
        "iop_failure",
        "med_failure",
        "surg_failure",
        "surgery_failed",
    ]:
        for it in range(nbr_iter):
            Y = dict_all_features[output_key]
            clf = LazyClassifier(verbose=0, ignore_warnings=True, custom_metric=None)
            X1_train, X1_test, y_train, y_test = train_test_split(
                X1, Y, test_size=0.2, random_state=it
            )
            models1, _ = clf.fit(X1_train, X1_test, y_train, y_test)
            top_acc_mean1 = (
                models1.sort_values("Accuracy", ascending=False)
                .head(3)["Accuracy"]
                .mean()
            )

            clf = LazyClassifier(verbose=0, ignore_warnings=True, custom_metric=None)
            X2_train, X2_test, y_train, y_test = train_test_split(
                X2, Y, test_size=0.2, random_state=it
            )
            models2, _ = clf.fit(X2_train, X2_test, y_train, y_test)
            top_acc_mean2 = (
                models2.sort_values("Accuracy", ascending=False)
                .head(3)["Accuracy"]
                .mean()
            )

            eval_dic["all_features"][output_key] += top_acc_mean1
            eval_dic["only_laterality"][output_key] += top_acc_mean2

        eval_dic["all_features"][output_key] /= nbr_iter
        eval_dic["only_laterality"][output_key] /= nbr_iter

    # Plotting:
    output_key = ["iop_failure", "med_failure", "surg_failure", "surgery_failed"]

    Y_1 = [eval_dic["all_features"][x] for x in output_key]
    Y_2 = [eval_dic["only_laterality"][x] for x in output_key]

    X_axis = np.arange(len(output_key))
    _, ax = plt.subplots()
    ax.bar(
        X_axis - 0.125, Y_1, 0.25, edgecolor="black", label="Laterality - All features"
    )
    ax.bar(
        X_axis + 0.125,
        Y_2,
        0.25,
        edgecolor="black",
        label="Laterality - Only relevant feature",
    )
    ax.set_ylim(0.6, 0.9)

    plt.xticks(X_axis, output_key)
    plt.xlabel("Output signal")
    plt.ylabel("Top Model Accuracy")
    title = "Comparison of laterality vs. non laterality FE, " + str(nbr_iter) + "iter"
    plt.title(title)
    plt.legend(loc="lower right")
    os.chdir("./feature_engineering")
    plt.savefig(title + ".png")
    os.chdir("..")
    plt.close()


def evaluate_and_plot_pca_vs_var_elim(
    nbr_feature_kept=20,
    nbr_iter=10,
    csv_path="/home/sambarry_stanford_edu/glaucoma_outcome_pred/data/data_glaucoma_surg.csv",
    split_per_surg=False,
    approachs={
        "glaucoma_meds": 2,
        "general_meds": 2,
        "diagnoses": 2,
        "diagnoses_1_nbr_char": 1,
    },
):

    pca_dic = {
        "glaucoma_meds": True,
        "general_meds": True,
        "diagnoses": True,
        "nbr_features": nbr_feature_kept,
    }
    var_elim_dict = {
        "glaucoma_meds": True,
        "general_meds": True,
        "diagnoses": True,
        "nbr_features": nbr_feature_kept,
    }

    eval_dic = {
        "all_features": defaultdict(float),
        "pca": defaultdict(float),
        "var_elim": defaultdict(float),
    }

    all_features = return_datasets(csv_path, split_per_surg, approachs)
    pca = return_datasets(csv_path, split_per_surg, approachs, pca_dic=pca_dic)
    var_elim = return_datasets(
        csv_path, split_per_surg, approachs, var_elim_dict=var_elim_dict
    )
    Xall, Xpca, Xelim = all_features["X"], pca["X"], var_elim["X"]

    for output_key in [
        "iop_failure",
        "med_failure",
        "surg_failure",
        "surgery_failed",
    ]:
        for it in range(nbr_iter):

            Y = all_features[output_key]
            clf = LazyClassifier(verbose=0, ignore_warnings=False, custom_metric=None)

            Xall_train, Xall_test, y_train, y_test = train_test_split(
                Xall, Y, test_size=0.2, random_state=it
            )
            modelsall, _ = clf.fit(Xall_train, Xall_test, y_train, y_test)
            top_acc_meanall = (
                modelsall.sort_values("Accuracy", ascending=False)
                .head(3)["Accuracy"]
                .mean()
            )

            clf = LazyClassifier(verbose=0, ignore_warnings=True, custom_metric=None)
            Xpca_train, Xpca_test, y_train, y_test = train_test_split(
                Xpca, Y, test_size=0.2, random_state=it
            )
            modelspca, _ = clf.fit(Xpca_train, Xpca_test, y_train, y_test)
            top_acc_meanpca = (
                modelspca.sort_values("Accuracy", ascending=False)
                .head(3)["Accuracy"]
                .mean()
            )

            clf = LazyClassifier(verbose=0, ignore_warnings=True, custom_metric=None)
            Xelim_train, Xelim_test, y_train, y_test = train_test_split(
                Xelim, Y, test_size=0.2, random_state=it
            )
            modelselim, _ = clf.fit(Xelim_train, Xelim_test, y_train, y_test)
            top_acc_meanelim = (
                modelselim.sort_values("Accuracy", ascending=False)
                .head(3)["Accuracy"]
                .mean()
            )

            eval_dic["all_features"][output_key] += top_acc_meanall
            eval_dic["pca"][output_key] += top_acc_meanpca
            eval_dic["var_elim"][output_key] += top_acc_meanelim

        eval_dic["all_features"][output_key] /= nbr_iter
        eval_dic["pca"][output_key] /= nbr_iter
        eval_dic["var_elim"][output_key] /= nbr_iter

    # Plotting:
    output_key = ["iop_failure", "med_failure", "surg_failure", "surgery_failed"]

    Y_1 = [eval_dic["all_features"][x] for x in output_key]
    Y_2 = [eval_dic["pca"][x] for x in output_key]
    Y_3 = [eval_dic["var_elim"][x] for x in output_key]

    X_axis = np.arange(len(output_key))
    _, ax = plt.subplots()
    ax.bar(
        X_axis - 0.25,
        Y_1,
        0.25,
        edgecolor="black",
        label="Feature Elimination - All features",
    )
    ax.bar(X_axis, Y_2, 0.25, edgecolor="black", label="Feature Elimination - PCA")
    ax.bar(
        X_axis + 0.25,
        Y_3,
        0.25,
        edgecolor="black",
        label="Feature Elimination - Variance Elimination",
    )
    ax.set_ylim(0.6, 0.9)

    plt.xticks(X_axis, output_key)
    plt.xlabel("Output signal")
    plt.ylabel("Top Model Accuracy")
    title = (
        "Comparison of features elimination methods, "
        + str(nbr_feature_kept)
        + " features, "
        + str(nbr_iter)
        + "iter"
    )
    plt.title(title)
    plt.legend(loc="lower right")
    os.chdir("./feature_engineering")
    plt.savefig(title + ".png")
    os.chdir("..")
    plt.close()


def return_top_correlation_pairs(value_dict, nbr_pairs=20):
    X = value_dict["X"]
    Y = value_dict["surgery_failed"]
    """
    Plots the top nbr_pairs columns of X correlated with Y 
    """
    
    X = X.filter(regex='(?i)^(?!.*glm.*|.*icd.*|.*gem.*)')

    df = pd.concat([X, Y], axis=1)
    corr = df.corr()[Y.name]
    corr = corr.sort_values(ascending=False)
    corr = corr.drop(Y.name)
    top_corr = corr.head(nbr_pairs)
    
    ax = top_corr.plot.bar()
    labels = [ '\n'.join(wrap(l, 10)) for l in top_corr.index]
    ax.set_xticklabels(labels)
    plt.xlabel('Feature')
    plt.ylabel('Correlation')
    plt.title('Top positive correlation between covariates and surgery failure')
    plt.yticks(fontsize=8)
    plt.xticks(fontsize=8)
    ax.set_xticklabels(top_corr.index, rotation=45, ha='right')
    plt.tight_layout()
    plt.savefig('Top positive correlation.png')

    # corr_df = X.corr().abs().unstack()
    # corr_df = corr_df.sort_values(ascending=False).drop_duplicates()
    # return corr_df.head(nbr_pairs)




if __name__ == "__main__":
    

    value_dict = return_datasets(var_elim_dict={
        "glaucoma_meds": True,
        "general_meds": True,
        "diagnoses": True,
        "nbr_features": 20
    })
    print(return_top_correlation_pairs(value_dict, nbr_pairs = 20))
    # evaluate_and_plot_pca_vs_var_elim(nbr_feature_kept=20, nbr_iter=10)

    # evaluate_and_plot_laterality_approach()
    # evaluate_approaches_only_one_approach_feature()
    # evaluate_approaches_all_features()
    # plot_evaluate_approaches(read_path="/home/sambarry_stanford_edu/glaucoma_outcome_pred/eval_only_approach_features.txt")
    #
    # dic = return_datasets(split_per_surg=False, approachs=OPTIMAL_APPROACHES)
    # get_shap_lime()


