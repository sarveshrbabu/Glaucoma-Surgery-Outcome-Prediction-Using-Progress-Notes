import json
import sys
import warnings
import itertools
import numpy as np
from pathlib import Path
from pactools.grid_search import GridSearchCVProgressBar
from sklearn.discriminant_analysis import (LinearDiscriminantAnalysis,
                                           QuadraticDiscriminantAnalysis)
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import *
from sklearn.model_selection import *
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from lightgbm import LGBMClassifier
from xgboost.sklearn import XGBClassifier

sys.path.insert(0, '/home/sambarry_stanford_edu/glaucoma_outcome_pred')
from feature_engineering.feature_engineering import *

warnings.simplefilter("always", DeprecationWarning) 

# PLEASE DON'T TOUCH THE SEED AND TEST SIZE SINCE THE TEST SET WOULD VARY
SEED_DATASET_SPLIT = 12
TEST_SIZE = 0.2
EVAL_SIZE = 0.2 # 20% of the train split previously defined (OR 5-fold CV for grid search)
OPTIMAL_APPROACHS = {
        "glaucoma_meds": 2,
        "general_meds": 2,
        "diagnoses": 1,
        "diagnoses_1_nbr_char": 2,
    }
MODEL_DIC = {
    "LogisticRegression": LogisticRegression,
    "MLPClassifier": MLPClassifier,
    "LinearDiscriminantAnalysis": LinearDiscriminantAnalysis,
    "KNeighborsClassifier": KNeighborsClassifier,
    "SVC": SVC,
    "DecisionTreeClassifier": DecisionTreeClassifier,
    "RandomForestClassifier": RandomForestClassifier,
    "GradientBoostingClassifier": GradientBoostingClassifier,
    "GaussianNB": GaussianNB,
    "QuadraticDiscriminantAnalysis": QuadraticDiscriminantAnalysis,
}


def custom_train_test_split(X, Y, alpha=0.8, seed=None):
    """
    Custom train-test split function that splits a dataset of two dataframe X and Y 
    into X_train, X_test, Y_train, Y_test, with:
    - A shuffle of the lists with a predetermined seed
    - A portion ~alpha for the train set (vs ~(1-alpha) for the test set)
    - Two dataframes with the same attributes "mrn" should always be in the same set ie we never split 
      two surgeries of the same patients into two different sets
    """
    assert 0 < alpha < 1

    if seed is not None:
        np.random.seed(seed)
    
    # Create a list of indices and shuffle X and Y accordingly
    indices = list(range(len(X)))
    np.random.shuffle(indices)

    # Resetting the index to later filter on mrn
    X = X.reset_index(drop=True)

    # Split indices into train and test sets
    split_index = int(alpha * len(indices))
    train_indices = indices[:split_index]
    test_indices = indices[split_index:]
    
    # Ensure that elements with the same mrn values are in the same dataset:
    for i in train_indices:
        if X.iloc[i]["mrn"] in X.iloc[test_indices]["mrn"].values:
            test_indices.append(i)
            train_indices.remove(i)

    for i in test_indices:
        if X.iloc[i]["mrn"] in X.iloc[train_indices]["mrn"].values:
            train_indices.append(i)
            test_indices.remove(i)
    
    # Correct the fact that our percentage of train/ test split drastically changed
    while abs(alpha - len(train_indices)/ (len(train_indices) + len(test_indices))) > 0.005:
        # If we have too many training examples. That should not happen, but lets still plan for it (useful to ensure termination if we add too many test examples)
        if len(train_indices) > alpha * (len(train_indices) + len(test_indices)):
            idx = train_indices[-1]
            associated_mrn = X.iloc[idx]["mrn"]
            list_of_ids_associated_with_mrn = X[X["mrn"] == associated_mrn].index
            for ids in list_of_ids_associated_with_mrn:
                # Just a security check. That should always be the case
                if ids in train_indices:
                    test_indices.append(ids)
                    train_indices.remove(ids)

        # Otherwise, it's that we have too many test examples:
        else:
            idx = test_indices[-1]
            associated_mrn = X.iloc[idx]["mrn"]
            list_of_ids_associated_with_mrn = X[X["mrn"] == associated_mrn].index
            for ids in list_of_ids_associated_with_mrn:
                # Just a security check. That should always be the case
                if ids in test_indices:
                    train_indices.append(ids)
                    test_indices.remove(ids)

        # Shuffling to avoid always picking the same. We absolutely don't touch the seed to keep the split deterministic!
        np.random.shuffle(train_indices)
        np.random.shuffle(test_indices)
    
    X_train = X.iloc[train_indices]
    X_test = X.iloc[test_indices]
    Y_train = Y.iloc[train_indices]
    Y_test = Y.iloc[test_indices]
    
    print("Test split generated, with alpha = {}".format(round(len(X_train.index)/(len(X_train.index) + len(X_test.index)),3)))
    return X_train, X_test, Y_train, Y_test


def get_datasets(csv_path="/home/sambarry_stanford_edu/glaucoma_outcome_pred/data/data_glaucoma_surg.csv", output_key="surgery_failed", test_size=0.2, surg_type=None, seed=None, keep_mrn=False):

    assert output_key in [
        "iop_below_5",
        "iop_above_17",
        "iop_above_19",
        "iop_above_21",
        "iop_failure",
        "med_failure",
        "revision_after_surg",
        "other_surg_after_surg",
        "surg_failure",
        "surgery_failed",
    ]
    # assert surg_type in ["Tube Shunt", "Trabeculectomy", "MIGS", None]
    assert surg_type in ["tube_shunt", "trabeculectomy", "migs", None]

    data_dict = return_datasets(
        csv_path,
        split_per_surg=(surg_type != None),
        approachs={
            "glaucoma_meds": 2,
            "general_meds": 2,
            "diagnoses": 1,
            "diagnoses_1_nbr_char": 2,
        },
        adjust_laterality_features=True,
        pca_dic={
            "glaucoma_meds": False,
            "general_meds": False,
            "diagnoses": False,
            "nbr_features": 100,
        },
        var_elim_dict={
            "glaucoma_meds": False,
            "general_meds": False,
            "diagnoses": False,
            "nbr_features": 100,
        },
    )

    if surg_type is not None:
        data_dict["X"] = data_dict[surg_type]["X"]
        data_dict[output_key] = data_dict[surg_type][output_key]
    
    X_train, X_test, Y_train, Y_test = custom_train_test_split(data_dict["X"], data_dict[output_key], alpha = 1-test_size, seed=seed)
    if not keep_mrn:
        X_train.drop(["mrn"], axis=1, inplace=True)
        X_test.drop(["mrn"], axis=1, inplace=True)

    return X_train, X_test, Y_train, Y_test


def get_model_names_and_parameters():

    models = {
    "LinearDiscriminantAnalysis": LinearDiscriminantAnalysis,
    "GaussianNB": GaussianNB,
    "MLPClassifier": MLPClassifier,
    "LogisticRegression": LogisticRegression,
    "KNeighborsClassifier": KNeighborsClassifier,
    "DecisionTreeClassifier": DecisionTreeClassifier,
    "SVC": SVC,
    "RandomForestClassifier": RandomForestClassifier,
    "GradientBoostingClassifier": GradientBoostingClassifier,

    # "LGBMClassifier": LGBMClassifier,
    # "XGBClassifier": XGBClassifier,
} 

    rf_params = {
            "bootstrap": [True, False],
            "max_depth": [10, 20, 40, 60, 80, 100, None],
            "max_features": ["auto", "sqrt"],
            # "criterion": ["gini", "entropy", "log_loss"],
            "criterion": ["gini", "entropy"], #log loss not available in sklearn < 1.1.2
            "min_samples_leaf": [1, 2, 4],
            "min_samples_split": [2, 5, 10],
            "n_estimators": [50, 100, 200, 400, 1000],
        }

    dtree_params = {
        "max_depth": [10, 20, 40, 60, 80, 100, None],
        "max_features": ["auto", "sqrt"],
        # "criterion": ["gini", "entropy", "log_loss"],
        "criterion": ["gini", "entropy"], #log loss not available in sklearn < 1.1.2
        "min_samples_leaf": [1, 2, 4],
        "min_samples_split": [2, 5, 10],
    }

    logreg_params = {
        "penalty": ["l1", "l2", "elasticnet", None],
        "fit_intercept": [True, False],
        "solver": ["lbfgs", "liblinear", "newton-cg", "saga"],
    }

    mlp_params = {
        "hidden_layer_sizes": [(10,), (20,), (50,), (100,), (200,), (400,)],
        "activation": ["identity", "logistic", "tanh", "relu"],
        "alpha": [0.00001, 0.0001, 0.001],
        "learning_rate": ["constant", "invscaling", "adaptive"],
    }

    knn_params = {
        "n_neighbors": [2, 3, 4, 5, 7, 9, 11, 15, 21, 31],
        "weights": ["uniform", "distance"],
        "algorithm": ["ball_tree", "kd_tree", "brute"],
        "p": [1, 2, 3],
    }

    lda_params = {
        "solver": ["svd", "lsqr", "eigen"],

    }

    gnb_params = {
        "var_smoothing": [1e-10, 1e-9, 1e-8]
    }

    svc_params = {
        "kernel": ["linear", "poly", "rbf", "sigmoid"],
        "C": [0.2, 0.5, 1, 2, 5],
        "gamma": ["scale", "auto"],
    }

    xboost_params = {
        "loss": ["log_loss", "deviance", "exponential"],
        "subsample": [1,2,5],
        "criterion": ["friedman_mse", "squared_error"],
        "n_estimators": [50, 100, 200],
        # "min_sample_split": [2, 3, 5, 10], # Not available in sklearn < 1.1.2
        "max_depth": [20, 50, 100, None],
        "max_features": ["auto", "sqrt"],
        "min_samples_leaf": [1, 2, 4],
        "min_samples_split": [2, 5, 10],
    }

    params = {
    "RandomForestClassifier": rf_params,
    "LogisticRegression": logreg_params,
    "MLPClassifier": mlp_params,
    "KNeighborsClassifier": knn_params,
    "LinearDiscriminantAnalysis": lda_params,
    "DecisionTreeClassifier": dtree_params,
    "GaussianNB": gnb_params,
    "SVC": svc_params,
    "GradientBoostingClassifier": xboost_params,
    }

    return models, params


def evaluate(model, X_test, y_test, verbose=True):
    """Leverages sklearn module to return the evaluation metrics of the model provided"""

    y_pred = model.predict(X_test)

    evaluation_dic = {
        "accuracy": accuracy_score(y_true=y_test, y_pred=y_pred),
        "balanced_accuracy": balanced_accuracy_score(y_true=y_test, y_pred=y_pred),
        "f1": f1_score(y_true=y_test, y_pred=y_pred),
        "precision": precision_score(y_true=y_test, y_pred=y_pred),
        "recall": recall_score(y_true=y_test, y_pred=y_pred),
    }

    if verbose:

        def round_dic(dic, ndigits=2):
            for k in dic.keys():
                dic[k] = round(dic[k], ndigits=ndigits)
            return dic

        print("Model evaluation metrics: ", round_dic(evaluation_dic))

    return evaluation_dic


def plot_roc(model, X_test, y_test):
    """Plot the roc curve of the specified model"""
    RocCurveDisplay.from_estimator(model, X_test, y_test)
    plt.show()


def plot_bar_charts(title, xlabel, ylabel, xticks, labels, axis_size=0.25, **args):
    # /!\ A CHECK pour les args
    # /!\ A CHECK pour generer des couleurs random
    X_axis = np.arange(len(xticks))
    _, ax = plt.subplots()


    for i in range(len(args)):
        ax.bar(X_axis - 0.25*(i//2 - i), args[i], 0.25, edgecolor="black", label=labels[i])    
    

    plt.xticks(X_axis, xticks)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.title(title)
    plt.legend(loc="lower right")
    plt.savefig(title + ".png")
    plt.close()
 

def load_optimal_model(model_name="GradientBoostingClassifier", output_key="surgery_failed", read_folder="./results"):
    assert model_name in MODEL_DIC.keys()
    assert output_key in ["surgery_failed", "iop_failure", "med_failure", "surg_failure"]

    read_path = read_folder + "/" + output_key + ".json"
    if not Path(read_path).is_file():
        read_path = "models/" + read_folder + "/" + output_key + ".json"
        if not Path(read_path).is_file():
            raise FileNotFoundError("Parameter dictionnary not found")
   
    with open(read_path, "r") as f:
        param_dic = json.loads(f.read())
        model_params = param_dic[model_name]
        model = MODEL_DIC[model_name](**model_params)

        X_train, _, Y_train, _ = get_datasets(output_key="surgery_failed", test_size=TEST_SIZE, surg_type=None, seed=SEED_DATASET_SPLIT)
        model.fit(X_train, Y_train)
        
        return model


def get_shap_lime(model_name="GradientBoostingClassifier", output_key="surgery_failed"):

    dic = return_datasets(split_per_surg=False, approachs=OPTIMAL_APPROACHS)
    X, Y = dic["X"], dic[output_key]
    X.drop(["mrn"], axis=1, inplace=True)

    col_idx_matching = {col: i for i,col in enumerate(X.columns)}

    model = load_optimal_model(model_name)

    # Initialize a Tree SHAP explainer
    explainer = shap.Explainer(model)

    # Compute the SHAP values for all instances:
    shap_values = explainer.shap_values(X)
    
    # Directly plot the result:
    shap.summary_plot(shap_values, X, max_display=30)
    plt.savefig('./models/results/shap_values.png')
    plt.close()
    shap.summary_plot(shap_values, X, plot_type="bar", max_display=30)
    plt.savefig('./models/results/shap_values_bar.png')
    plt.close()

    # Grouping features together (icd/gem/glm/proc_year/cpt together)
    
    aggregated_shap_values = {}
    aggregated_abs_shap_values = {}
    cols_dic = {}
    filter_cols = lambda substr: [col for col in X.columns if substr in col] 
    for col_group_str in ["icd", "gem", "glm", "proc_year", "cpt"]:
        cols_dic[col_group_str] = filter_cols(col_group_str)


    for col_group_str in ["icd", "gem", "glm", "proc_year", "cpt"]:
        col_group = cols_dic[col_group_str]
        shap_sum_cols = np.zeros((1,len(shap_values)))
        shap_abs_sum_cols = np.zeros((1,len(shap_values)))
        for col in col_group:
            shap_sum_cols += shap_values[:,col_idx_matching[col]]
            shap_abs_sum_cols += abs(shap_values[:,col_idx_matching[col]])

        aggregated_shap_values[col_group_str] = np.mean(shap_sum_cols)
        aggregated_abs_shap_values[col_group_str] = np.mean(shap_abs_sum_cols)
    
    # Aggregating over all the remainings cols:
    for col in X.columns:
        if col not in list(itertools.chain(cols_dic["icd"], cols_dic["gem"], cols_dic["glm"], cols_dic["proc_year"], cols_dic["cpt"])):
            aggregated_shap_values[col] = np.mean(shap_values[:,col_idx_matching[col]])
            aggregated_abs_shap_values[col] = np.mean(abs(shap_values[:,col_idx_matching[col]])) #Abs is useless here but taking it just in case



    aggregated_shap_values = dict(sorted(aggregated_shap_values.items(), key=lambda x: x[1], reverse=True))
    aggregated_abs_shap_values = dict(sorted(aggregated_abs_shap_values.items(), key=lambda x: x[1], reverse=False))
    aggregated_shap_values_result_summed = dict(sorted(aggregated_shap_values_result_summed.items(), key=lambda x: x[1], reverse=False))


    # Imitate the shap ratio to plot our own diagrams
    _, ax = plt.subplots(figsize=(12, 16))
    _ = ax.barh(list(aggregated_shap_values.keys()), list(aggregated_shap_values.values()))
    plt.xlabel('Shape ratio')
    plt.ylabel('Feature/ Group of feature')
    plt.title('Shape ratio of the features aggregated per column type')
    plt.yticks(fontsize=10)
    plt.xticks(fontsize=10)
    # plt.tight_layout()
    plt.savefig('models/results/shap_values_grouped.png')

    _, ax = plt.subplots(figsize=(12, 16))
    _ = ax.barh(list(aggregated_shap_values_result_summed.keys()), list(aggregated_shap_values_result_summed.values()))
    plt.xlabel('Shape ratio')
    plt.ylabel('Feature/ Group of feature')
    plt.title('Shape ratio of the features aggregated per column type')
    plt.yticks(fontsize=10)
    plt.xticks(fontsize=10)
    # plt.tight_layout()
    plt.savefig('models/results/shap_values_grouped_result_abs.png')
    
    _, ax = plt.subplots(figsize=(12, 16))
    _ = ax.barh(list(aggregated_abs_shap_values.keys()), list(aggregated_abs_shap_values.values()))
    plt.xlabel('Shape ratio')
    plt.ylabel('Feature/ Group of feature')
    plt.title('Shape ratio of the features aggregated per column type')
    plt.yticks(fontsize=10)
    plt.xticks(fontsize=10)
    # plt.tight_layout()
    plt.savefig('models/results/shap_values_grouped_sum_abs.png')
    



