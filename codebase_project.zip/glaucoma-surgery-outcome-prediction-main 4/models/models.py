import json
from collections import defaultdict
import sys
# from pactools.grid_search import GridSearchCVProgressBar
from sklearn.discriminant_analysis import (
    LinearDiscriminantAnalysis,
    QuadraticDiscriminantAnalysis,
)
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import *
from sklearn.model_selection import *
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from lightgbm import LGBMClassifier
from xgboost.sklearn import XGBClassifier

sys.path.insert(0, '/home/sambarry_stanford_edu/glaucoma_outcome_pred')
from feature_engineering.feature_engineering import *
from utils import *


def grid_search(
    csv_path,
    classifier,
    param_grid,
    output_key="surgery_failed",
    verbose=True,
    surg_type=None,
    test_size=0.2,
    seed=None,
):
    """
    Performs a grid search for the model/params provided and returns the best model/params and the
    associated accuracy metrics
    """

    # USE GridSearchCVProgressBar insteda
    grid_search = GridSearchCVProgressBar(
        estimator=classifier(),
        param_grid=param_grid,
        cv=5,
        n_jobs=-1,
        verbose=2,
        scoring="accuracy",
    )

    if not surg_type:
        X_train, X_test, y_train, y_test = get_datasets(
            csv_path, output_key, test_size=test_size, seed=seed
        )
    else:
        X_train, X_test, y_train, y_test = get_datasets(
            csv_path, output_key, test_size=test_size, seed=seed
        )
    grid_search.fit(X_train, y_train)
    best_model, best_params = grid_search.best_estimator_, grid_search.best_params_

    model_metrics = evaluate(best_model, X_test, y_test, verbose=verbose)

    if verbose:
        print("Best params found: {}".format(best_params))
        print(classification_report(y_test, best_model.predict(X_test)))
        # plot_roc(best_model, X_test, y_test)

    return best_model, best_params, model_metrics


def get_top_model_params(
    csv_path,
    model_dic,
    model_param,
    output_key="surgery_failed",
    write_folder="./results",
    test_size=0.2,
    seed=None,
):
    """
    Iterates through all the input models to perform grid search and store the best performing models
    parameters in a json file

    model_dic format: {"RandomForestClassifier": RandomForestClassifier, ...}
    model_param format: {"RandomForestClassifier": {"tree_width": 40, ...}, ...}
    """
    write_path_params = write_folder + "/" + output_key + ".json"
    write_path_eval = write_folder + "/" + output_key + "_eval.json"

    for model in model_dic.keys():

        start_time = datetime.now()

        classifier, param_grid = model_dic[model], model_param[model]
        _, best_params, model_metric = grid_search(
            csv_path,
            classifier,
            param_grid,
            output_key,
            verbose=True,
            test_size=test_size,
            seed=seed,
        )
        print(
            "Gridsearch for {} completed in: {}".format(
                model, datetime.now() - start_time
            )
        )

        try:
            with open(write_path_params, "r") as f:
                param_dic = json.loads(f.read())
        except FileNotFoundError:
            param_dic = {}

        # Appending the model parameters to the dic, and writing it back
        param_dic[model] = best_params
        with open(write_path_params, "w") as f:
            f.write(json.dumps(param_dic))

        try:
            with open(write_path_eval, "r") as f:
                eval_dic = json.loads(f.read())
        except FileNotFoundError:
            eval_dic = {}

        # Appending the model evaluation metrics to the dic, and writing it back
        eval_dic[model] = model_metric
        with open(write_path_eval, "w") as f:
            f.write(json.dumps(eval_dic))


if __name__ == "__main__":
    
    # model_dic, model_param = get_model_names_and_parameters()

    # for output_key in ["surgery_failed", "iop_failure", "med_failure", "surg_failure"]:
    # for output_key in ["iop_failure", "med_failure", "surg_failure"]:
    #     get_top_model_params(
    #         "/home/sambarry_stanford_edu/glaucoma_outcome_pred/data/data_glaucoma_surg.csv",
    #         model_dic,
    #         model_param,
    #         output_key=output_key,
    #         write_folder="./results",
    #         test_size=TEST_SIZE,
    #         seed=SEED_DATASET_SPLIT
    #     )
    #     string = "Parameter research completed for output key" + output_key
    #     sys.stdout.write(string)
    get_shap_lime()

    # model = load_optimal_model()
    # X_train, _, Y_train, _ = get_datasets(output_key="surgery_failed", test_size=TEST_SIZE, surg_type=None, seed=SEED_DATASET_SPLIT)
    # x0 = X_train.iloc[0]   
    # print(model.predict[x0]) # => Only outputs True /False
    # print(model.predict_proba([x0])) # => Outputs the proba of True/ False

