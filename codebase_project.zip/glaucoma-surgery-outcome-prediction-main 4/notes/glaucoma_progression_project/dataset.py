import config
import torch
import pandas as pd
import sys

sys.path.insert(0, '/home/sambarry_stanford_edu/glaucoma_outcome_pred')
from torch.utils import data
from models.utils import *
from feature_engineering.feature_engineering import *

class GlaucomaSurgeryDataset(torch.utils.data.Dataset):
    """
    Pytorch Dataset which is consistent with the input requirement of the Trainer
    """
    def __init__(self, encodings, labels):
        self.encodings = encodings
        self.labels = labels

    def __getitem__(self, idx):
        item = {key: torch.tensor(val[idx]) for key, val in self.encodings.items()}
        item['labels'] = torch.tensor(self.labels[idx])
        return item

    def __len__(self):
        return len(self.labels)


def read_glaucoma_surgery_train_test_val(
        data_url=config.data_url,
        output_key=config.output_key,
        test_split=config.test_split,
        val_split=config.val_split, 
        seed=config.seed
    ):
    """
    This function read in the glaucoma surgery data with the specified data url.
    We hold out test_split % for the test set, and val_split %  of the remaining rows for the validation set
    This function will return the train, val, test data
    """
    data_dic = return_datasets(csv_path=data_url)
    X, Y = data_dic["X"], data_dic[output_key]

    X_train_and_val, X_test, Y_train_and_val, Y_test = custom_train_test_split(X, Y, alpha=(1-test_split), seed=seed)
    X_train, X_val, Y_train, Y_val = custom_train_test_split(X_train_and_val, Y_train_and_val, alpha=(1-val_split), seed=seed)
    
    return X_train, X_val, X_test, Y_train, Y_val, Y_test 

    


def get_texts_labels_split(X, Y):
    """
    This function split the glaucoma surgey data into text and labels.
    In the glaucoma surgey data, text are in col ind2, label is in the last col
    """

    texts = X["notes"].values.tolist()
    labels_binary = Y.values.tolist()
    labels = [[1, 0] if y else [0, 1] for y in labels_binary]
    
    return texts, labels