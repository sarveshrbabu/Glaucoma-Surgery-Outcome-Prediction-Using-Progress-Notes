import logging
import config
import manual_trainer
import dataset
import model
import utils
import os
import sys
import torch
import faulthandler
faulthandler.enable()


from torch.utils import data
from torch.utils.tensorboard import SummaryWriter
from transformers import TrainingArguments
from transformers import Trainer
from transformers import EarlyStoppingCallback
from transformers import AutoModelForSequenceClassification, AutoTokenizer
from datetime import *

#Define the logger
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
formatter = logging.Formatter('%(levelname)s:%(name)s:%(message)s')
stream_handler = logging.StreamHandler()
stream_handler.setFormatter(formatter)
logger.addHandler(stream_handler)

os.environ["TOKENIZERS_PARALLELISM"] = "false"

train_data = [("The cat is cute", "Positive"), 
            ("The dog is happy", "Positive"), 
            ("The sky is blue", "Positive"), 
            ("I hate broccoli", "Negative"), 
            ("The weather is bad", "Negative")]

val_data = [("The sun is shining", "Positive"), 
        ("I love pizza", "Positive"), 
        ("The traffic is terrible", "Negative"), 
        ("I'm feeling sad", "Negative"), 
        ("The book was boring", "Negative")]



current_time = datetime.now()
print_current_time = current_time.strftime("%d/%m/%Y %H:%M:%S")
folder_adding_current_time = current_time.strftime("_%d_%m_%Y_%H_%M_%S")
data_url = "/home/sambarry_stanford_edu/glaucoma_outcome_pred/data/data_glaucoma_surg_concatenated_notes.csv"
num_train_epochs = 10  # total number of epochs
per_device_train_batch_size = 16  # batch size per device during training
per_device_eval_batch_size = 8  # batch size for evaluation
warmup_steps = 4  # number of warmup steps for learning rate scheduler
learning_rate = 0.00003 #learning rate
weight_decay = 0.01  # strength of weight decay
logging_steps = 100 #evey logging_steps print out the results
evaluation_strategy = 'steps' #every logging_steps print out the results
seed = 42 #Seed to make sure the replicate of the training
load_best_model_at_end = True #Load the best model after training
metric_for_best_model = 'eval_loss' #best model was selected by using this metrics
greater_is_better = False #How to use metric_for_best_model
pos_weight = 2205/881 #Applied pos_weights when calculating the BCELoss
gradient_accumulation_steps = 2  #gradient_accumulation_steps
model_name = 'bert-base-uncased' #Pre-trained model want to use
do_lower_case = True #Whether do lower case processing on the test
model_saving_dir = '/home/sambarry_stanford_edu/glaucoma_outcome_pred/notes/glaucoma_progression_project/results/' + model_name + folder_adding_current_time + '_seed_' + str(seed)
output_dir = model_saving_dir + '/results'  # output directory
logging_dir = model_saving_dir + '/logs'  # directory for storing logs
max_length = 512 #Maximum length of the text
early_stop = 3  #Number of steps of early stop
early_stop_thresh = 0.0 #Threshold of early stops
hidden_dropout_prob = 0.1   #Dropout rate before the linear classifier layer
output_key = "surgery_failed"
test_split = 0.2
val_split = 0.2

# writer = SummaryWriter(log_dir='expt/%s/%s_%s_%d_pt_lr_%f_ft_lr_%f' % (
#     args.function,
#     args.tb_expt_name,
#     args.variant,
#     args.bottleneck_dim,
#     args.pretrain_lr,
#     args.finetune_lr))
writer = SummaryWriter(log_dir='results/')

def run():
    """
    This function read in the specified train, val, test data.
    Data was tokenized and processed to the model required format.
    Specified pre-trained model and param were loaded into the Trainer.
    The pre-trained model was finetuned on the training data and evaluated on the val data.
    """

    #Read in the train, val, test glaucoma surgey data
    X_train, X_val, X_test, Y_train, Y_val, Y_test  = dataset.read_glaucoma_surgery_train_test_val(data_url)
    logger.info('load in glaucoma surgery data for train, val and test')

    #Split the text and labels for train, val and test
    train_texts, train_labels = dataset.get_texts_labels_split(X_train, Y_train)
    val_texts, val_labels = dataset.get_texts_labels_split(X_val, Y_val)
    test_texts, test_labels = dataset.get_texts_labels_split(X_test, Y_test)
    logger.info(f'train texts shape, labels shape {len(train_texts), len(train_labels)}')
    logger.info(f'val texts shape, labels shape {len(val_texts), len(val_labels)}')
    logger.info(f'test texts shape, labels shape {len(test_texts), len(test_labels)}')

    #Load in the pretrained model and tokenizer
    tokenizer = AutoTokenizer.from_pretrained(model_name, do_lower_case=do_lower_case)
    # pretrained_model = AutoModelForSequenceClassification.from_pretrained(config.model_name, num_labels=2, hidden_dropout_prob=config.hidden_dropout_prob)
    pretrained_model = AutoModelForSequenceClassification.from_pretrained(model_name, num_labels=2)
    logger.info(f'load in the specified pretrained model {pretrained_model.name_or_path} and its associated tokenizer')

    #Tokenize the text with the tokenizer
    train_encodings = tokenizer(train_texts, truncation=True, padding=True, max_length=max_length)
    val_encodings = tokenizer(val_texts, truncation=True, padding=True, max_length=max_length)
    test_encodings = tokenizer(test_texts, truncation=True, padding=True, max_length=max_length)
    logger.info('tokenize the train, val and test text with the given tokenizer')

    #Prepare the Pytorch Dataset
    train_dataset = dataset.GlaucomaSurgeryDataset(train_encodings, train_labels)
    val_dataset = dataset.GlaucomaSurgeryDataset(val_encodings, val_labels)
    test_dataset = dataset.GlaucomaSurgeryDataset(test_encodings, test_labels)
    logger.info('Put the train, val and test encodings into the GlaucomaSurgeryDataset class')

    # #Set up the training arguments
    # training_args = TrainingArguments(
    #     output_dir=config.output_dir,          # output directory
    #     num_train_epochs=config.num_train_epochs,              # total number of training epochs
    #     per_device_train_batch_size=config.per_device_train_batch_size,  # batch size per device during training
    #     per_device_eval_batch_size=config.per_device_eval_batch_size,   # batch size for evaluation
    #     warmup_steps=config.warmup_steps,                # number of warmup steps for learning rate scheduler
    #     learning_rate=config.learning_rate,              #Learning rate
    #     weight_decay=config.weight_decay,               # strength of weight decay
    #     logging_dir=config.logging_dir,            # directory for storing logs
    #     logging_steps=config.logging_steps,        #loging steps
    #     evaluation_strategy=config.evaluation_strategy,     #evaluation strategy: steps or epochs
    #     seed=config.seed,   #Seed to control the random
    #     load_best_model_at_end=config.load_best_model_at_end,   #Whether load in the best model in the end
    #     metric_for_best_model=config.metric_for_best_model,     #Metrics used for the best model
    #     greater_is_better=config.greater_is_better,     #higher/lower metrics score, better model performance
    #     gradient_accumulation_steps=config.gradient_accumulation_steps,     #number of gradient accumulation steps
    #     report_to=None       #Platform to monitor the training process
    # )
    # logger.info('Load in the specified training arguments')

    # #set up the glaucoma_surgery_trainer
    # glaucoma_surgery_trainer = model.BinarySequenceClassificationTrainer(
    #     model=pretrained_model,  # the instantiated Transformers model to be trained
    #     args=training_args,  # training arguments, defined above
    #     train_dataset = train_data,
    #     eval_dataset = val_data,
    #     # train_dataset=train_dataset,  # training dataset
    #     # eval_dataset=val_dataset,  # evaluation dataset
    #     # compute_metrics=model.compute_metrics,  #evaluation Metrics
    #     callbacks=[EarlyStoppingCallback(config.early_stop, config.early_stop_thresh)] #early Stop
    # )

    print("Before config")
    config = manual_trainer.TrainerConfig(
            max_epochs=10,
            batch_size=8,
            learning_rate=0.001,
            lr_decay=True,
            warmup_tokens=512*20,
            final_tokens=200*len(train_dataset),
            num_workers=4,
            writer=writer
        )

    print("Before trainer loading")
    trainer = manual_trainer.Trainer(pretrained_model, train_data, None, config)
    print("Before training")
    trainer.train()
    

    



    logger.info('Load the glaucoma_surgery_trainer')

    #Take model training
    glaucoma_surgery_trainer.train()
    logger.info('Training finished')

    #Saving the best model and its associated tokenizer
    glaucoma_surgery_trainer.save_model(config.model_saving_dir)
    tokenizer.save_pretrained(config.model_saving_dir)
    logger.info(f'Saving best model and its associated tokenizer in {config.model_saving_dir}')

    #Model Evaluation Results on val data
    logger.info('Results from the best model on evaluation dataset:')
    glaucoma_surgery_trainer.evaluate()

if __name__=="__main__":
    utils.set_seed(config.seed)
    run()
    utils.convert_config_log_to_json(config.model_saving_dir)


